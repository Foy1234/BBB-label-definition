# B3DB original-record evidence reconstruction and frozen-input validation

Status: **PASS**

Classification: 7807 source rows; 7803 valid rows; 4020 unique parents.
Continuous logBB: 1058 source rows; 1056 valid measurements; 926 unique parents.
Vote: 1157 common training parents compared; 0 vote mismatches; 0 first-record hard-label mismatches; 8 nonbinary vote values.
logBB: 4131 frozen consensus parents compared; 0 mismatched parent rows; 1 valid regression-only parent identities not present in the frozen consensus.

Reconstruction does not regenerate or overwrite the frozen consensus, frozen labels, Stage II targets, predictions, or manuscript statistics.

For detailed field-level comparisons see logbb_consensus_frozen_comparison.csv and vote_common1157_frozen_comparison.csv.
The recorded software versions are those of the execution environment; compatibility is verified by the molecule-level comparisons, not inferred from version equality.
