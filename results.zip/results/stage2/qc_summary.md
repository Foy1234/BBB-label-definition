# Stage II target construction — QC summary

**PASS: target construction and numerical quality-control checks completed.**

- Source consensus hash: `51d09eea4e6a1659ea7820a93f5f63880161645c3bab8f7f9f93007bdbc9849a`
- Source labels hash: `ea6b31d500e1f04384952a096fabdf4e9ce3e0bd9533587442c542946f432c89`
- Common training n: 1157; full train pool n: 1234
- b3db_n: 1157
- bbbp_n: 18
- logbb_n: 186
- b3db_distinct_state_n_gt1: 8
- b3db_conflict_n: 8
- b3db_distinct_state_entries: 1165
- logbb_effective_rows: 200
- standardization_logbb_mean: -0.3063440860215054
- standardization_logbb_sd: 0.8382555618551861
- B3DB q_B source: frozen label_B reconstructed from original B3DB_classification.tsv by legacy stage7; original row multiplicities NOT recoverable from consensus raw_labels
- Frozen Vote vs deduplicated consensus states: 3 discordant fractions; max difference 0.1666666667; support contradictions 0
- Full original B3DB TSV was not independently re-read in this run; sample count of original duplicate records remains unknown.
- Lambda=0.01: 64 cycles; objective=126.305572; δ=-0.60257, a=0.33177, b=-0.80816, σ=1.00000
- Lambda=0.1: 50 cycles; objective=384.283305; δ=0.14277, a=0.80234, b=-0.81831, σ=1.00000
- Lambda=1.0: 81 cycles; objective=702.783874; δ=0.53859, a=3.38545, b=-0.81023, σ=1.00000
- Gradient max error: 5.85e-08
- Order invariance max target diff: 0
- Permutable training molecules: 1152; changed per permutation min/avg/max: 184/191.4/196

## Important interpretation
The 99 conditional permutations preserve the exact Integrated target multiset within each frozen (Hard, BBBP-present, logBB-present) stratum. They do not form independent observations and do not test model performance in this stage.
The Integrated target is a penalized, molecule-balanced composite-likelihood target, not a physiological BBB probability or an exact Bayesian posterior.
logBB values are standardized using only the 1157 train molecules (equal weight by molecule); logBB observation-noise SD is FIXED to 1 on this scale to prevent nonidentifiable variance collapse when most measured molecules have only one observation. The data do not justify interpreting this as an estimated assay noise SD.

## Generated files
- labels_abc_corrected_STAGE2_ONLY.csv (1234 pool rows, compatible with the existing downstream masks)
- stage2_target_vectors_common1157.csv
- P_99_permutation_targets_common1157.csv
- target_distributions.csv; fit_parameters.csv; lambda_pairwise_target_sensitivity.csv

The original frozen labels_abc.csv remains unchanged; XGBoost/GINE evaluation is performed in the subsequent modeling stage.
